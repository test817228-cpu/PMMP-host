package com.pmmphost

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import java.io.File
import java.io.IOException
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** Owns the PocketMine-MP process, its console buffer and its state. */
object ServerManager {
    enum class State { STOPPED, STARTING, RUNNING, STOPPING }

    interface Listener {
        fun onLine(line: CharSequence) {}
        fun onState(state: State) {}
        fun onCleared() {}
    }

    private const val MAX_LINES = 3000
    private const val COLOR_INFO = 0xFF60A5FA.toInt()
    private const val COLOR_ERROR = 0xFFF87171.toInt()
    private const val COLOR_INPUT = 0xFF93C5FD.toInt()

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val buffer = ArrayDeque<CharSequence>()   // touched on main thread only
    private val writer = Executors.newSingleThreadExecutor()

    @Volatile private var process: Process? = null

    @Volatile
    var state = State.STOPPED
        private set

    fun addListener(l: Listener) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }

    /** Main thread only. */
    fun snapshot(): List<CharSequence> = buffer.toList()

    private fun setState(s: State) {
        state = s
        main.post { listeners.forEach { it.onState(s) } }
    }

    private fun push(line: CharSequence) {
        main.post {
            buffer.addLast(line)
            if (buffer.size > MAX_LINES) buffer.removeFirst()
            listeners.forEach { it.onLine(line) }
        }
    }

    fun systemLine(msg: String, error: Boolean = false) {
        val s = SpannableString(msg)
        s.setSpan(
            ForegroundColorSpan(if (error) COLOR_ERROR else COLOR_INFO),
            0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        push(s)
    }

    fun clear() {
        main.post {
            buffer.clear()
            listeners.forEach { it.onCleared() }
        }
    }

    private fun findPhp(context: Context, dir: File): File? {
        val candidates = listOf(
            File(context.applicationInfo.nativeLibraryDir, "libphp.so"),
            File(dir, "bin/php7/bin/php"),
            File(dir, "bin/php5/bin/php")
        )
        return candidates.firstOrNull { it.exists() && it.canExecute() }
    }

    private fun findTarget(dir: File): File? {
        val phar = File(dir, "PocketMine-MP.phar")
        if (phar.isFile) return phar
        val src = File(dir, "src/pocketmine/PocketMine.php")
        if (src.isFile) return src
        return dir.listFiles { f -> f.isFile && f.extension == "phar" }?.firstOrNull()
    }

    @Synchronized
    fun start(context: Context, dir: File) {
        if (state != State.STOPPED) return
        setState(State.STARTING)
        try {
            if (!dir.isDirectory) throw IllegalStateException("Server folder not found: ${dir.path}")
            val php = findPhp(context, dir) ?: throw IllegalStateException(
                "PHP binary not found. Add libphp.so to jniLibs (see README)."
            )
            val target = findTarget(dir) ?: throw IllegalStateException(
                "No PocketMine-MP.phar or src/pocketmine/PocketMine.php in ${dir.path}"
            )
            systemLine("Starting ${target.name} with ${php.path}")
            val pb = ProcessBuilder(php.absolutePath, target.absolutePath)
            pb.directory(dir)
            pb.redirectErrorStream(true)
            val env = pb.environment()
            env["HOME"] = dir.absolutePath
            env["TERM"] = "xterm"
            val libDir = context.applicationInfo.nativeLibraryDir
            env["LD_LIBRARY_PATH"] = libDir + (env["LD_LIBRARY_PATH"]?.let { ":$it" } ?: "")
            val p = pb.start()
            process = p
            setState(State.RUNNING)
            Thread({ readLoop(p) }, "pm-console").start()
        } catch (e: Exception) {
            systemLine("Failed to start: ${e.message}", error = true)
            process = null
            setState(State.STOPPED)
        }
    }

    private fun readLoop(p: Process) {
        try {
            p.inputStream.bufferedReader().forEachLine { push(AnsiParser.parse(it)) }
        } catch (_: IOException) {
        }
        val code = try { p.waitFor() } catch (_: InterruptedException) { -1 }
        systemLine("Server stopped (exit code $code)", error = code != 0)
        if (process === p) process = null
        setState(State.STOPPED)
    }

    /** Sends a console command to the server. Returns false if the server is not running. */
    fun sendCommand(cmd: String): Boolean {
        val p = process ?: return false
        if (!p.isAlive) return false
        val echo = SpannableString("> $cmd")
        echo.setSpan(ForegroundColorSpan(COLOR_INPUT), 0, echo.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        push(echo)
        writer.execute {
            try {
                p.outputStream.write((cmd + "\n").toByteArray())
                p.outputStream.flush()
            } catch (_: IOException) {
            }
        }
        return true
    }

    /** Graceful shutdown: sends "stop" to the server. */
    fun stop() {
        if (state == State.RUNNING) {
            setState(State.STOPPING)
            sendCommand("stop")
        }
    }

    /** Force shutdown (SIGKILL). */
    fun kill() {
        val p = process ?: return
        systemLine("Force killing server...", error = true)
        p.destroyForcibly()
    }
}
