package com.pmmphost

import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan

/** Converts ANSI escape codes (ESC[...m) and Minecraft section-sign codes into colored text. */
object AnsiParser {
    private fun c(rgb: Int) = 0xFF000000.toInt() or rgb

    private val ansi = intArrayOf(
        c(0x6B7280), c(0xF14C4C), c(0x23D18B), c(0xF5F543),
        c(0x3B8EEA), c(0xD670D6), c(0x29B8DB), c(0xE5E5E5)
    )
    private val ansiBright = intArrayOf(
        c(0x9CA3AF), c(0xFF6B6B), c(0x4ADE80), c(0xFDE047),
        c(0x60A5FA), c(0xF0ABFC), c(0x22D3EE), c(0xFFFFFF)
    )
    private const val MC_CODES = "0123456789abcdef"
    private val mc = intArrayOf(
        c(0x6B7280), c(0x3B5BDB), c(0x16A34A), c(0x0891B2),
        c(0xDC2626), c(0x9333EA), c(0xF59E0B), c(0xD1D5DB),
        c(0x9CA3AF), c(0x60A5FA), c(0x4ADE80), c(0x22D3EE),
        c(0xF87171), c(0xF0ABFC), c(0xFDE047), c(0xFFFFFF)
    )

    private fun color256(n: Int): Int = when {
        n < 8 -> ansi[n.coerceAtLeast(0)]
        n < 16 -> ansiBright[n - 8]
        n < 232 -> {
            val v = n - 16
            fun lvl(x: Int) = if (x == 0) 0 else 55 + 40 * x
            c((lvl(v / 36) shl 16) or (lvl((v / 6) % 6) shl 8) or lvl(v % 6))
        }
        else -> {
            val g = (8 + 10 * (n.coerceAtMost(255) - 232))
            c((g shl 16) or (g shl 8) or g)
        }
    }

    fun parse(input: String): CharSequence {
        val sb = SpannableStringBuilder()
        val text = StringBuilder()
        var fg: Int? = null
        var bold = false
        var underline = false

        fun flush() {
            if (text.isEmpty()) return
            val start = sb.length
            sb.append(text)
            text.setLength(0)
            val end = sb.length
            fg?.let { sb.setSpan(ForegroundColorSpan(it), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (underline) sb.setSpan(UnderlineSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        var i = 0
        while (i < input.length) {
            val ch = input[i]
            if (ch == '\u001B') {
                if (i + 1 < input.length && input[i + 1] == '[') {
                    var j = i + 2
                    while (j < input.length && input[j] !in '@'..'~') j++
                    if (j >= input.length) { i = input.length; continue }
                    if (input[j] == 'm') {
                        flush()
                        val params = input.substring(i + 2, j)
                        val codes = if (params.isEmpty()) listOf(0) else params.split(';').map { it.toIntOrNull() ?: 0 }
                        var k = 0
                        while (k < codes.size) {
                            val code = codes[k]
                            when {
                                code == 0 -> { fg = null; bold = false; underline = false }
                                code == 1 -> bold = true
                                code == 4 -> underline = true
                                code == 22 -> bold = false
                                code == 24 -> underline = false
                                code == 39 -> fg = null
                                code in 30..37 -> fg = ansi[code - 30]
                                code in 90..97 -> fg = ansiBright[code - 90]
                                code == 38 && k + 2 < codes.size && codes[k + 1] == 5 -> {
                                    fg = color256(codes[k + 2]); k += 2
                                }
                                code == 38 && k + 4 < codes.size && codes[k + 1] == 2 -> {
                                    fg = c(((codes[k + 2] and 0xFF) shl 16) or ((codes[k + 3] and 0xFF) shl 8) or (codes[k + 4] and 0xFF))
                                    k += 4
                                }
                            }
                            k++
                        }
                    }
                    i = j + 1
                } else {
                    i++
                }
            } else if (ch == '\u00A7' && i + 1 < input.length) {
                val code = input[i + 1].lowercaseChar()
                val idx = MC_CODES.indexOf(code)
                flush()
                when {
                    idx >= 0 -> { fg = mc[idx]; bold = false; underline = false }
                    code == 'l' -> bold = true
                    code == 'n' -> underline = true
                    code == 'r' -> { fg = null; bold = false; underline = false }
                }
                i += 2
            } else if (ch == '\r') {
                i++
            } else {
                text.append(ch)
                i++
            }
        }
        flush()
        return sb
    }
}
