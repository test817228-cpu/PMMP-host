package com.pmmphost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.pmmphost.ServerManager.State
import com.pmmphost.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("pmmphost", MODE_PRIVATE) }
    private var backingUp = false

    private val listener = object : ServerManager.Listener {
        override fun onState(state: State) = updateButtons()
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val path = treeUriToPath(uri)
            if (path == null) {
                toast("Please pick a folder inside storage (not the storage root)")
            } else {
                prefs.edit().putString("dir", path).apply()
                updateFolder()
            }
        }
    }
    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnFolder.setOnClickListener { pickFolder.launch(null) }
        b.btnStart.setOnClickListener { startServer() }
        b.btnStop.setOnClickListener { ServerManager.stop() }
        b.btnKill.setOnClickListener { confirmKill() }
        b.btnBackup.setOnClickListener { backup() }
        b.btnConsole.setOnClickListener { startActivity(Intent(this, ConsoleActivity::class.java)) }
        updateFolder()
    }

    override fun onStart() {
        super.onStart()
        ServerManager.addListener(listener)
        updateButtons()
    }

    override fun onStop() {
        ServerManager.removeListener(listener)
        super.onStop()
    }

    private fun serverDir(): String? = prefs.getString("dir", null)

    private fun updateFolder() {
        b.tvFolder.text = serverDir() ?: "No server folder selected"
    }

    private fun treeUriToPath(uri: Uri): String? {
        val docId = DocumentsContract.getTreeDocumentId(uri)
        val parts = docId.split(":", limit = 2)
        val volume = parts[0]
        val rel = parts.getOrElse(1) { "" }
        if (rel.isEmpty()) return null
        val base = if (volume == "primary") Environment.getExternalStorageDirectory().path else "/storage/$volume"
        return "$base/$rel"
    }

    private fun hasStorageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
        toast("Allow file access, then try again")
    }

    private fun startServer() {
        val dir = serverDir() ?: return toast("Select your server folder first")
        if (!hasStorageAccess()) return requestStorageAccess()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        ContextCompat.startForegroundService(
            this, Intent(this, ServerService::class.java).putExtra("dir", dir)
        )
    }

    private fun confirmKill() {
        AlertDialog.Builder(this)
            .setTitle("Force kill server?")
            .setMessage("The server will be stopped immediately. Unsaved data may be lost.")
            .setPositiveButton("Kill") { _, _ -> ServerManager.kill() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun backup() {
        val dir = serverDir() ?: return toast("Select your server folder first")
        if (!hasStorageAccess()) return requestStorageAccess()
        if (backingUp) return
        backingUp = true
        updateButtons()
        toast("Backup started...")
        Thread {
            val result = try {
                if (ServerManager.state == State.RUNNING) {
                    ServerManager.sendCommand("save-all")
                    Thread.sleep(2500)
                }
                val f = BackupManager.backup(File(dir))
                ServerManager.systemLine("Backup saved: ${f.path}")
                Result.success(f)
            } catch (e: Exception) {
                ServerManager.systemLine("Backup failed: ${e.message}", error = true)
                Result.failure(e)
            }
            runOnUiThread {
                backingUp = false
                updateButtons()
                result.onSuccess { toast("Backup saved in ${BackupManager.BACKUP_FOLDER}/${it.name}") }
                    .onFailure { toast("Backup failed: ${it.message}") }
            }
        }.start()
    }

    private fun updateButtons() {
        val s = ServerManager.state
        val (label, colorRes) = when (s) {
            State.STOPPED -> "Offline" to R.color.red
            State.STARTING -> "Starting..." to R.color.orange
            State.RUNNING -> "Online" to R.color.green
            State.STOPPING -> "Stopping..." to R.color.orange
        }
        b.tvStatus.text = label
        b.dot.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, colorRes))
        setEnabledUi(b.btnStart, s == State.STOPPED)
        setEnabledUi(b.btnStop, s == State.RUNNING)
        setEnabledUi(b.btnKill, s != State.STOPPED)
        setEnabledUi(b.btnBackup, !backingUp)
    }

    private fun setEnabledUi(v: View, on: Boolean) {
        v.isEnabled = on
        v.alpha = if (on) 1f else 0.4f
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
