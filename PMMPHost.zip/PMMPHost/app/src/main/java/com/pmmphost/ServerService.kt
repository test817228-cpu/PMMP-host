package com.pmmphost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.pmmphost.ServerManager.State
import java.io.File

/** Foreground service that keeps the server process alive while the app is in the background. */
class ServerService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    private val listener = object : ServerManager.Listener {
        override fun onState(state: State) {
            when (state) {
                State.STOPPED -> {
                    ServiceCompat.stopForeground(this@ServerService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
                State.STARTING -> notify("Starting...")
                State.RUNNING -> notify("PocketMine-MP is running")
                State.STOPPING -> notify("Stopping...")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification("Starting..."),
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pmmphost:server").also { it.acquire() }
        }
        ServerManager.removeListener(listener)
        ServerManager.addListener(listener)

        val dir = intent?.getStringExtra("dir")
        if (dir == null) {
            stopSelf()
        } else {
            ServerManager.start(this, File(dir))
            if (ServerManager.state == State.STOPPED) stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ServerManager.removeListener(listener)
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Server status", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("PMMP Host")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    companion object {
        private const val CHANNEL = "server"
        private const val NOTIF_ID = 1
    }
}
