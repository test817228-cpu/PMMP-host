package com.pmmphost

import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.pmmphost.ServerManager.State
import com.pmmphost.databinding.ActivityConsoleBinding

class ConsoleActivity : AppCompatActivity() {
    private lateinit var b: ActivityConsoleBinding
    private val adapter = LineAdapter()
    private var autoScroll = true

    private val listener = object : ServerManager.Listener {
        override fun onLine(line: CharSequence) {
            adapter.add(line)
            if (autoScroll) b.list.scrollToPosition(adapter.itemCount - 1)
        }

        override fun onState(state: State) = updateStatus()
        override fun onCleared() = adapter.setAll(emptyList())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityConsoleBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.list.itemAnimator = null
        b.list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                autoScroll = !rv.canScrollVertically(1)
            }
        })

        b.btnClear.setOnClickListener { ServerManager.clear() }
        b.btnSend.setOnClickListener { send() }
        b.input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
    }

    override fun onStart() {
        super.onStart()
        adapter.setAll(ServerManager.snapshot())
        ServerManager.addListener(listener)
        updateStatus()
        autoScroll = true
        if (adapter.itemCount > 0) b.list.scrollToPosition(adapter.itemCount - 1)
    }

    override fun onStop() {
        ServerManager.removeListener(listener)
        super.onStop()
    }

    private fun send() {
        val cmd = b.input.text.toString().trim()
        if (cmd.isEmpty()) return
        if (ServerManager.sendCommand(cmd)) {
            b.input.setText("")
            autoScroll = true
        } else {
            Toast.makeText(this, "Server is not running", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatus() {
        b.tvConsoleStatus.text = when (ServerManager.state) {
            State.STOPPED -> "Offline"
            State.STARTING -> "Starting..."
            State.RUNNING -> "Online"
            State.STOPPING -> "Stopping..."
        }
    }
}

class LineAdapter : RecyclerView.Adapter<LineAdapter.VH>() {
    private val items = ArrayList<CharSequence>()

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = TextView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(0xFFD1D5DB.toInt())
            val pad = (4 * resources.displayMetrics.density).toInt()
            setPadding(pad * 2, pad / 2, pad * 2, pad / 2)
        }
        return VH(tv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tv.text = items[position]
    }

    override fun getItemCount() = items.size

    fun setAll(list: List<CharSequence>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun add(line: CharSequence) {
        items.add(line)
        notifyItemInserted(items.size - 1)
        if (items.size > 3000) {
            items.removeAt(0)
            notifyItemRemoved(0)
        }
    }
}
