package com.pmmphost

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Zips the server folder into a "PocketMine-Backups" folder created next to it
 * (same storage location as the server folder).
 */
object BackupManager {
    const val BACKUP_FOLDER = "PocketMine-Backups"

    @Throws(IOException::class)
    fun backup(serverDir: File): File {
        val parent = serverDir.parentFile ?: throw IOException("Server folder has no parent folder")
        val backupDir = File(parent, BACKUP_FOLDER)
        if (!backupDir.exists() && !backupDir.mkdirs()) {
            throw IOException("Cannot create ${backupDir.path}")
        }
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val out = File(backupDir, "${serverDir.name}-$stamp.zip")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zip ->
                addDir(zip, serverDir, serverDir.name, backupDir)
            }
        } catch (e: Exception) {
            out.delete()
            throw e
        }
        return out
    }

    private fun addDir(zip: ZipOutputStream, dir: File, path: String, skip: File) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f == skip) continue
            val entry = "$path/${f.name}"
            if (f.isDirectory) {
                zip.putNextEntry(ZipEntry("$entry/"))
                zip.closeEntry()
                addDir(zip, f, entry, skip)
            } else if (f.isFile) {
                zip.putNextEntry(ZipEntry(entry))
                f.inputStream().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }
}
