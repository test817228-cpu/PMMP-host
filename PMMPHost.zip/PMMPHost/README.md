# PMMP Host

Android app (Kotlin) that runs a PocketMine-MP server from a folder on your device.

Buttons: Start, Shut Down (sends `stop`), Kill (force), Backup, Open Console.
Backup zips the server folder into a sibling folder named `PocketMine-Backups`.
The console supports ANSI colors and Minecraft section-sign (§) color codes, and has a command box.

## Setup
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Add a PHP binary for Android, built for your PocketMine version (old MCPE 0.15.x builds need
   PHP 7 with pthreads, i.e. a ZTS build), renamed to `libphp.so`:
   - `app/src/main/jniLibs/arm64-v8a/libphp.so` (and `armeabi-v7a/` for 32-bit phones)
   Android 10+ cannot execute files from app data or shared storage, but it can execute
   libraries in the native library folder, which is why the binary is shipped as `libphp.so`.
3. Build and install. In the app: Select Server Folder (the folder that contains
   `PocketMine-MP.phar` or `src/pocketmine/PocketMine.php`), allow "All files access", press Start.
